﻿namespace SWIFT_INTERMODAL_API.Helper
{
    public class Helper
    {
    }
}
